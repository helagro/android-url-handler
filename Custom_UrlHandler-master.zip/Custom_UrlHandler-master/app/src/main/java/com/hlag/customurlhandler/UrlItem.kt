package com.hlag.customurlhandler

data class UrlItem(var id: Long, var name: String, var url: String, var app: String, var broadcast: String?)